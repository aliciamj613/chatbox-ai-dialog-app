package com.example.chatbox.data.remote

// ======================= 文本对话 =======================

data class ChatMessage(
    val role: String,
    val content: String
)

data class ChatRequest(
    // 这里你可以换成自己想用的通用模型，比如 "GLM-4.5", "GLM-4-Plus" 等
    val model: String = "GLM-4-Plus",
    val messages: List<ChatMessage>,
    val temperature: Double = 0.8,
    val top_p: Double = 0.7
)

data class Choice(
    val message: ChatMessage
)

data class ChatResponse(
    val choices: List<Choice>
)


// ======================= 文生图 =======================
// 对应：POST /api/paas/v4/images/generations

data class ImageRequest(
    // 你可用的图像大模型里有：CogView-4-250304 / CogView-4 / CogView-3-Plus 等
    // 这里先用一个通用的 "CogView-4"
    val model: String = "CogView-4",
    val prompt: String,
    val size: String? = "1024x1024",         // 可选：256x256 / 512x512 / 1024x1024
    val quality: String? = "standard",       // 可选：standard / hd（具体以文档为准）
    val user_id: String? = null
)

data class ImageData(
    val url: String
)

data class ImageResponse(
    val created: Long,
    val data: List<ImageData> = emptyList()
)


// ======================= 文生视频 =======================
// 1. 生成任务:  POST /api/paas/v4/videos/generations
// 2. 查结果:    GET  /api/paas/v4/async-result/{id}

data class VideoRequest(
    // 你可用的视频模型里有：CogVideoX, CogVideoX-2, CogVideoX-3, CogVideoX-Flash, ViduQ1-text 等
    // 这里先用一个通用的 "CogVideoX-2"
    val model: String = "CogVideoX-2",
    val prompt: String,
    val duration: Int? = null,              // 可选，秒数
    val resolution: String? = null,         // 可选，如 "720p"
    val user_id: String? = null
)

// 第一步：创建任务返回
data class VideoTaskResponse(
    val id: String,
    val model: String,
    val request_id: String?,
    val task_status: String                 // e.g. "PROCESSING" / "SUCCESS" / "FAILED"
)

// 第二步：查询结果
data class VideoResult(
    val url: String,
    val cover_image_url: String?
)

data class VideoResultResponse(
    val model: String,
    val video_result: List<VideoResult>?,
    val task_status: String,                // 同样是 "SUCCESS" / "FAILED" / "PROCESSING"
    val request_id: String?
)
