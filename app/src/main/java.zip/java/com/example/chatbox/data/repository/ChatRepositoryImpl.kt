package com.example.chatbox.data.repository

import android.util.Log
import com.example.chatbox.data.local.db.ConversationDao
import com.example.chatbox.data.local.db.MessageDao
import com.example.chatbox.data.model.MessageEntity
import com.example.chatbox.data.remote.ChatApiService
import com.example.chatbox.data.remote.ChatMessage
import com.example.chatbox.data.remote.ChatRequest
import com.example.chatbox.data.remote.ImageRequest
import com.example.chatbox.data.remote.VideoRequest
import com.example.chatbox.domain.model.Message
import com.example.chatbox.domain.repository.ChatRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import retrofit2.HttpException
import java.io.IOException

class ChatRepositoryImpl(
    private val messageDao: MessageDao,
    private val conversationDao: ConversationDao,
    private val api: ChatApiService
) : ChatRepository {

    // =============== 历史（有“记忆”的基础） ===============

    override fun getHistory(conversationId: Long): Flow<List<Message>> {
        return messageDao.observeMessages(conversationId).map { entities ->
            entities.map { entity ->
                Message(
                    id = entity.id,
                    text = entity.text,
                    isUser = entity.isUser,
                    timestamp = entity.timestamp
                )
            }
        }
    }

    // =============== 1. 纯文本对话（带上下文记忆） ===============

    override suspend fun sendOnlineMessage(
        userText: String,
        conversationId: Long
    ): Result<Unit> {
        return try {
            val now = System.currentTimeMillis()

            // 1) 先写入当前这条用户消息
            messageDao.insertMessage(
                MessageEntity(
                    text = userText,
                    isUser = true,
                    timestamp = now,
                    conversationId = conversationId
                )
            )

            // 2) 取出整段历史作为上下文
            val historyEntities = messageDao.getMessagesByConversation(conversationId)
            val historyMessages = historyEntities.map { entity ->
                ChatMessage(
                    role = if (entity.isUser) "user" else "assistant",
                    content = entity.text
                )
            }

            val request = ChatRequest(
                messages = historyMessages
            )

            // 3) 调用文本对话接口
            val response = api.sendChat(request)
            val replyText = response.choices.firstOrNull()?.message?.content
                ?: "AI 没有返回内容"

            val replyTime = System.currentTimeMillis()

            // 4) 写入 AI 回复
            messageDao.insertMessage(
                MessageEntity(
                    text = replyText,
                    isUser = false,
                    timestamp = replyTime,
                    conversationId = conversationId
                )
            )

            // 5) 更新会话标题 & 更新时间
            updateConversationMetaAfterReply(
                conversationId = conversationId,
                lastUserText = userText,
                updatedAt = replyTime
            )

            Result.success(Unit)
        } catch (e: HttpException) {
            Log.e("ChatRepositoryImpl", "HTTP error: ${e.code()} ${e.message()}", e)
            Result.failure(e)
        } catch (e: IOException) {
            Log.e("ChatRepositoryImpl", "Network error: ${e.message}", e)
            Result.failure(e)
        } catch (e: Exception) {
            Log.e("ChatRepositoryImpl", "Unexpected error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // =============== 2. 文生图（把图片 URL 写成一条 AI 消息） ===============

    override suspend fun generateImageFromText(
        prompt: String,
        conversationId: Long
    ): Result<Unit> {
        return try {
            val now = System.currentTimeMillis()

            // 把“生成图片”请求记录下来
            messageDao.insertMessage(
                MessageEntity(
                    text = "[图片请求] $prompt",
                    isUser = true,
                    timestamp = now,
                    conversationId = conversationId
                )
            )

            val request = ImageRequest(
                prompt = prompt
            )

            val response = api.generateImage(request)
            val url = response.data.firstOrNull()?.url
                ?: "图片生成失败（接口未返回 URL）"

            val replyTime = System.currentTimeMillis()
            val replyText = "图片已生成：$url"

            messageDao.insertMessage(
                MessageEntity(
                    text = replyText,
                    isUser = false,
                    timestamp = replyTime,
                    conversationId = conversationId
                )
            )

            updateConversationMetaAfterReply(
                conversationId = conversationId,
                lastUserText = prompt,
                updatedAt = replyTime
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("ChatRepositoryImpl", "generateImage error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // =============== 3. 文生视频（异步轮询结果） ===============

    override suspend fun generateVideoFromText(
        prompt: String,
        conversationId: Long
    ): Result<Unit> {
        return try {
            val now = System.currentTimeMillis()

            // 把“视频请求”记录下来
            messageDao.insertMessage(
                MessageEntity(
                    text = "[视频请求] $prompt",
                    isUser = true,
                    timestamp = now,
                    conversationId = conversationId
                )
            )

            // 1) 创建生成任务
            val taskResponse = api.generateVideo(
                VideoRequest(
                    prompt = prompt
                    // 需要可以加 duration / resolution 等参数
                )
            )

            val taskId = taskResponse.id
            var finalUrl: String? = null
            var finalStatus: String = taskResponse.task_status

            // 2) 轮询 async-result，最多等 10 次（每次 2 秒）
            repeat(10) {
                delay(2000)

                val result = api.getVideoResult(taskId)
                finalStatus = result.task_status

                val url = result.video_result?.firstOrNull()?.url
                if (finalStatus.equals("SUCCESS", ignoreCase = true) && url != null) {
                    finalUrl = url
                    return@repeat
                }

                if (finalStatus.equals("FAILED", ignoreCase = true)) {
                    return@repeat
                }
            }

            val replyTime = System.currentTimeMillis()
            val replyText = when {
                finalUrl != null -> "视频已生成：$finalUrl"
                finalStatus.equals("FAILED", ignoreCase = true) ->
                    "视频生成失败，请稍后重试。"
                else ->
                    "视频生成任务已提交（任务 ID：$taskId），请稍后重试查看结果。"
            }

            // 3) 写回一条 AI 消息
            messageDao.insertMessage(
                MessageEntity(
                    text = replyText,
                    isUser = false,
                    timestamp = replyTime,
                    conversationId = conversationId
                )
            )

            updateConversationMetaAfterReply(
                conversationId = conversationId,
                lastUserText = prompt,
                updatedAt = replyTime
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("ChatRepositoryImpl", "generateVideo error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // =============== 会话标题 & 更新时间统一更新 ===============

    private suspend fun updateConversationMetaAfterReply(
        conversationId: Long,
        lastUserText: String,
        updatedAt: Long
    ) {
        val conversation = conversationDao.getConversationById(conversationId)
        if (conversation != null) {
            val shouldUpdateTitle =
                conversation.title.isBlank() ||
                        conversation.title == "新的对话" ||
                        conversation.title.startsWith("对话 #")

            val newTitle = if (lastUserText.isNotBlank() && shouldUpdateTitle) {
                val trimmed = lastUserText.trim()
                if (trimmed.length <= 18) trimmed else trimmed.substring(0, 18) + "…"
            } else {
                conversation.title
            }

            conversationDao.updateConversation(
                conversation.copy(
                    title = newTitle,
                    updatedAt = updatedAt
                )
            )
        }
    }
}
