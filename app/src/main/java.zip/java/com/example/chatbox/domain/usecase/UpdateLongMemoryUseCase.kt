package com.example.chatbox.domain.usecase

class UpdateLongMemoryUseCase
