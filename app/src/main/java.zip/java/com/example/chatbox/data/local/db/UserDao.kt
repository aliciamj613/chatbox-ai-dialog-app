package com.example.chatbox.data.local.db

import androidx.room.Dao

@Dao
interface UserDao
