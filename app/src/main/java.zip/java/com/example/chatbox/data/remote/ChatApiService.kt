package com.example.chatbox.data.remote

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ChatApiService {

    // ========== 文本对话 ==========
    // POST https://open.bigmodel.cn/api/paas/v4/chat/completions
    @POST("paas/v4/chat/completions")
    suspend fun sendChat(
        @Body request: ChatRequest
    ): ChatResponse

    // ========== 文生图 ==========
    // POST https://open.bigmodel.cn/api/paas/v4/images/generations
    @POST("paas/v4/images/generations")
    suspend fun generateImage(
        @Body request: ImageRequest
    ): ImageResponse

    // ========== 文生视频：创建任务 ==========
    // POST https://open.bigmodel.cn/api/paas/v4/videos/generations
    @POST("paas/v4/videos/generations")
    suspend fun generateVideo(
        @Body request: VideoRequest
    ): VideoTaskResponse

    // ========== 文生视频：查询结果 ==========
    // GET https://open.bigmodel.cn/api/paas/v4/async-result/{id}
    @GET("paas/v4/async-result/{id}")
    suspend fun getVideoResult(
        @Path("id") taskId: String
    ): VideoResultResponse
}
