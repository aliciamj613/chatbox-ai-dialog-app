package com.example.chatbox.ui.login



data class LoginUiState(
    val userId: String = "",
    val isLoggingIn: Boolean = false
)

